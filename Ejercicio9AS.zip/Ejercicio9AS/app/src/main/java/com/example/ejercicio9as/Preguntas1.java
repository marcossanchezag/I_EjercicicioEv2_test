package com.example.ejercicio9as;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Preguntas1 extends AppCompatActivity {

    private Button boton1;
    private Button boton2;
    private Button boton3;
    private Obtener obtener; // Asegúrate de inicializar esta variable

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preguntas1);

        boton1 = findViewById(R.id.boton1r);
        boton2 = findViewById(R.id.boton2r);
        boton3 = findViewById(R.id.boton3r);

        // Inicializa 'obtener' aquí (puede ser a través de un constructor o método de inicialización)
        obtener = new Obtener(); // Asegúrate de tener una clase Obtener

        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obtener.setCorrecto(true); // Establece el valor correcto
                Intent abrirPantalla = new Intent(Preguntas1.this, Preguntas2.class); // Usa el contexto correcto
                abrirPantalla.putExtra("correcto", true); // Envía el valor booleano
                startActivity(abrirPantalla);
            }
        });

        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obtener.setCorrecto(false);
            }
        });

        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obtener.setCorrecto(false);
            }
        });
    }
}
