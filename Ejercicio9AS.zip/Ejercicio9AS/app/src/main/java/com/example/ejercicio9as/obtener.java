package com.example.ejercicio9as;

public class Obtener {

    // Nombre
    private static String nombre;

    public static void setNombre(String n) {
        nombre = n;
    }

    public static String getNombre() {
        return nombre;
    }

    // Respuesta correcta o incorrecta
    private static boolean correcto;

    public static void setCorrecto(boolean n) {
        correcto = n;
    }

    public static boolean getCorrecto() {
        return correcto;
    }
}
